<?php
defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Satuan extends REST_Controller
{
    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
    }
    
    //Menampilkan
    function index_get() {
        $id_satuan = $this->get('id_satuan');
        if ($id_satuan == '') {
            $ci_barang = $this->db->get('satuan')->result();
        } else {
            $this->db->where('id_satuan', $id_satuan);
            $ci_barang = $this->db->get('satuan')->result();
        }
        $this->response($ci_barang, 200);
    }

    function index_post() {
        $data = array(
                'id_satuan'       => $this->post('id_satuan'),
                'nama_satuan'          => $this->post('nama_satuan'));
        $insert = $this->db->insert('satuan', $data);
        if ($insert) {
            $this->response($data, 200);
        } else { 
            $this->response(array('status' => 'fail', 502));
        }
    }

    function index_put() {
        $id = $this->put('id_satuan');
        $data = array(
                    'id_satuan'       => $this->put('id_satuan'),
                    'nama_satuan'          => $this->put('nama_satuan'));
        $this->db->where('id_satuan', $id_satuan);
        $update = $this->db->update('satuan', $data);
        if ($update) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }

    function index_delete() {
        $id = $this->delete('id_satuan');
        $this->db->where('id_satuan', $id);
        $delete = $this->db->delete('satuan');
        if ($delete) {
            $this->response(array('status' => 'success'), 201);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }
    /*public function index()
    {
        $data['title'] = "Satuan";
        $data['satuan'] = $this->admin->get('satuan');
        $this->template->load('templates/dashboard', 'satuan/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('nama_satuan', 'Nama Satuan', 'required|trim');
    }

    public function add()
    {
        $this->_validasi();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Satuan";
            $this->template->load('templates/dashboard', 'satuan/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('satuan', $input);
            if ($insert) {
                set_pesan('data berhasil disimpan');
                redirect('satuan');
            } else {
                set_pesan('data gagal disimpan', false);
                redirect('satuan/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Satuan";
            $data['satuan'] = $this->admin->get('satuan', ['id_satuan' => $id]);
            $this->template->load('templates/dashboard', 'satuan/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('satuan', 'id_satuan', $id, $input);
            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('satuan');
            } else {
                set_pesan('data gagal disimpan', false);
                redirect('satuan/add');
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('satuan', 'id_satuan', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('satuan');
    }*/
}
