<?php

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Barangmasuk extends REST_Controller
{
    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();  
    }
    
    //Menampilkan
    function index_get() {
        $id_satuan = $this->get('id_barang_masuk');
        if ($id_barang_masuk == '') {
            $ci_barang = $this->db->get('barang_masuk')->result();
        } else {
            $this->db->where('id_barang_masuk', $id_barang_masuk);
            $ci_barang = $this->db->get('barang_masuk')->result();
        }
        $this->response($ci_barang, 200);
    }

    function index_post() {
        $data = array(
                'id_barang_masuk'       => $this->post('id_barang_masuk'),
                'nama_barang_masuk'          => $this->post('nama_barang_masuk'));
        $insert = $this->db->insert('barang_masuk', $data);
        if ($insert) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }

    function index_put() {
        $id = $this->put('id_barang_masuk');
        $data = array(
                    'id_barang_masuk'       => $this->put('id_barang_masuk'),
                    'nama_barang_masuk'          => $this->put('nama_barang_masuk'));
        $this->db->where('id_barang_masuk', $id_barang_masuk);
        $update = $this->db->update('barang_masuk', $data);
        if ($update) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }

    function index_delete() {
        $id = $this->delete('id_barang_masuk');
        $this->db->where('id_barang_masuk', $id);
        $delete = $this->db->delete('barang_masuk');
        if ($delete) {
            $this->response(array('barang_masuk' => 'success'), 201);
        } else {
            $this->response(array('barang_masuk' => 'fail', 502));
        }
    }
}

/*class Barangmasuk extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Barang Masuk";
        $data['barangmasuk'] = $this->admin->getBarangMasuk();
        $this->template->load('templates/dashboard', 'barang_masuk/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('tanggal_masuk', 'Tanggal Masuk', 'required|trim');
        $this->form_validation->set_rules('supplier_id', 'Supplier', 'required');
        $this->form_validation->set_rules('barang_id', 'Barang', 'required');
        $this->form_validation->set_rules('jumlah_masuk', 'Jumlah Masuk', 'required|trim|numeric|greater_than[0]');
    }

    public function add()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Barang Masuk";
            $data['supplier'] = $this->admin->get('supplier');
            $data['barang'] = $this->admin->get('barang');

            // Mendapatkan dan men-generate kode transaksi barang masuk
            $kode = 'T-BM-' . date('ymd');
            $kode_terakhir = $this->admin->getMax('barang_masuk', 'id_barang_masuk', $kode);
            $kode_tambah = substr($kode_terakhir, -5, 5);
            $kode_tambah++;
            $number = str_pad($kode_tambah, 5, '0', STR_PAD_LEFT);
            $data['id_barang_masuk'] = $kode . $number;

            $this->template->load('templates/dashboard', 'barang_masuk/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('barang_masuk', $input);

            if ($insert) {
                set_pesan('Data Berhasil Disimpan');
                redirect('barangmasuk');
            } else {
                set_pesan('Data Gagal Disimpan');
                redirect('barangmasuk/add');
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('barang_masuk', 'id_barang_masuk', $id)) {
            set_pesan('Data Dihapus');
        } else {
            set_pesan('Data Gagal Dihapus', false);
        }
        redirect('barangmasuk');
    }
}*/
